<?php
/**
 * Created by PhpStorm.
 * User: Josh
 * Date: 4/5/2017
 * Time: 10:35 AM
 */


$title      = get_sub_field('title');
$subtitle   = get_sub_field('subtitle');

